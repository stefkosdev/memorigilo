# memorigilo
Super reminder app

Założenia projektu:
https://docs.google.com/document/d/1fOZrVkycYTDkv3RziC1rJTgvAojdxlPOfTZoIsBt7gs/edit?usp=sharing
